// Package store offers a memory-based and a Redis-based throttled.Store implementation.
package store // import "gopkg.in/throttled/throttled.v1/store"
